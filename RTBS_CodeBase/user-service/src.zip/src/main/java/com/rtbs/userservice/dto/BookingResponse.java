package com.rtbs.userservice.dto;

import java.util.List;


public class BookingResponse {

	private int bookingId;
	private String boardingStationId, destinationStationId,  bookingClass;
	private int trainId, userId, pricePerTicket, numberOfPassengers;
	private List<PassengerTicket> passengers;  
	
	public BookingResponse()
	{
		
	}
	
	
	public BookingResponse(int bookingId, String boardingStationId, String destinationStationId, String bookingClass,
			int trainId, int userId, int pricePerTicket, int numberOfPassengers,
			List<PassengerTicket> passengers) {
		super();
		this.bookingId = bookingId;
		this.boardingStationId = boardingStationId;
		this.destinationStationId = destinationStationId;
		this.bookingClass = bookingClass;
		this.trainId = trainId;
		this.userId = userId;
		this.pricePerTicket = pricePerTicket;
		this.numberOfPassengers = numberOfPassengers;
		this.passengers = passengers;
	}


	@Override
	public String toString() {
		return "BookingResponse [bookingId=" + bookingId + ", boardingStationId=" + boardingStationId
				+ ", destinationStationId=" + destinationStationId + ", bookingClass=" + bookingClass + ", trainId="
				+ trainId + ", userId=" + userId + ", pricePerTicket=" + pricePerTicket + ", numberOfPassengers="
				+ numberOfPassengers + ", passengers=" + passengers + "]";
	}


	public int getBookingId() {
		return bookingId;
	}


	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}


	public String getBoardingStationId() {
		return boardingStationId;
	}


	public void setBoardingStationId(String boardingStationId) {
		this.boardingStationId = boardingStationId;
	}


	public String getDestinationStationId() {
		return destinationStationId;
	}


	public void setDestinationStationId(String destinationStationId) {
		this.destinationStationId = destinationStationId;
	}


	public String getBookingClass() {
		return bookingClass;
	}


	public void setBookingClass(String bookingClass) {
		this.bookingClass = bookingClass;
	}


	public int getTrainId() {
		return trainId;
	}


	public void setTrainId(int trainId) {
		this.trainId = trainId;
	}


	public int getUserId() {
		return userId;
	}


	public void setUserId(int userId) {
		this.userId = userId;
	}


	public int getPricePerTicket() {
		return pricePerTicket;
	}


	public void setPricePerTicket(int pricePerTicket) {
		this.pricePerTicket = pricePerTicket;
	}


	public int getNumberOfPassengers() {
		return numberOfPassengers;
	}


	public void setNumberOfPassengers(int numberOfPassengers) {
		this.numberOfPassengers = numberOfPassengers;
	}


	public List<PassengerTicket> getPassengers() {
		return passengers;
	}


	public void setPassengers(List<PassengerTicket> passengers) {
		this.passengers = passengers;
	}
	
	

	
}
